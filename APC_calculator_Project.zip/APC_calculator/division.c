/* 
 Name : G Sai Deexith Kumar Reddy
 Date : 03.08.2025
 Description : APC (Arbitary precision calculator)
*/
#include "Dll.h"

// Perform integer division using linked lists
int div_number(Dlist **head1, Dlist **tail1,
               Dlist **head2, Dlist **tail2,
               Dlist **head3, Dlist **tail3, char ch)
{
    Dlist *temp = *head1;
    Dlist *list_h = NULL, *list_t = NULL;
    Dlist *h_div = NULL, *t_div = NULL;

    // Start with first digit of dividend
    dl_insert_last(&list_h, &list_t, temp->data);
    temp = temp->next;

    // Append digits until partial dividend >= divisor
    while (compare_num(*head2, *tail2, list_h, list_t) == FAILURE && temp != NULL)
    {
        dl_insert_last(&list_h, &list_t, temp->data);
        temp = temp->next;
    }

    // Perform recursive division
    do_divided(&list_h, &list_t, head2, tail2, head3, tail3, &h_div, &t_div, temp);

    // Remove leading zeros from quotient
    while (h_div && h_div->data == 0 && h_div->next)
    {
        dl_delete_first(&h_div, &t_div);
    }

    *head3 = h_div;
    *tail3 = t_div;

    // If no result digits, insert 0
    if (*head3 == NULL)
        dl_insert_first(head3, tail3, 0);

    return SUCCESS;
}

// Recursively perform division by repeated subtraction
int do_divided(Dlist **list_h, Dlist **list_t,
               Dlist **head2, Dlist **tail2,
               Dlist **head3, Dlist **tail3,
               Dlist **h_div, Dlist **t_div, Dlist *temp)
{
    int count = 0;

    // Reset temporary subtraction result
    *head3 = NULL;
    *tail3 = NULL;

    while (compare_num(*head2, *tail2, *list_h, *list_t) == SUCCESS)
    {
        sub_number_div(list_h, list_t, head2, tail2, head3, tail3);
        *list_h = *head3;
        *list_t = *tail3;

        // Prepare for next round
        *head3 = NULL;
        *tail3 = NULL;
        count++;
    }

    // Store quotient digit
    dl_insert_last(h_div, t_div, count);

    if (temp != NULL)
    {
        dl_insert_last(list_h, list_t, temp->data);
        do_divided(list_h, list_t, head2, tail2, head3, tail3, h_div, t_div, temp->next);
    }

    return SUCCESS;
}

// Compare two linked list numbers
int compare_num(Dlist *head2, Dlist *tail2, Dlist *list_h, Dlist *list_t)
{
    int len1 = 0, len2 = 0;
    Dlist *temp1 = head2;
    Dlist *temp2 = list_h;

    while (temp1) { len1++; temp1 = temp1->next; }
    while (temp2) { len2++; temp2 = temp2->next; }

    if (len2 < len1) return FAILURE;
    if (len2 > len1) return SUCCESS;

    temp1 = head2;
    temp2 = list_h;

    while (temp1 && temp2)
    {
        if (temp2->data > temp1->data) return SUCCESS;
        if (temp2->data < temp1->data) return FAILURE;
        temp1 = temp1->next;
        temp2 = temp2->next;
    }

    return SUCCESS;  // Equal or greater
}

// Subtract two linked list numbers: list_h - head2
int sub_number_div(Dlist **list_h, Dlist **list_t,
                   Dlist **head2, Dlist **tail2,
                   Dlist **head3, Dlist **tail3)
{
    Dlist *temp1 = *list_t;
    Dlist *temp2 = *tail2;
    int borrow = 0;

    while (temp1 != NULL)
    {
        int num1 = temp1->data;
        int num2 = (temp2 != NULL) ? temp2->data : 0;

        if (borrow)
        {
            num1--;
            borrow = 0;
        }

        if (num1 < num2)
        {
            num1 += 10;
            borrow = 1;
        }

        int result = num1 - num2;
        dl_insert_first(head3, tail3, result);

        temp1 = temp1->prev;
        if (temp2 != NULL) temp2 = temp2->prev;
    }

    // Remove leading zeros
    while (*head3 && (*head3)->data == 0 && (*head3)->next)
    {
        dl_delete_first(head3, tail3);
    }

    if (*head3 == NULL)
        dl_insert_first(head3, tail3, 0);

    return SUCCESS;
}
