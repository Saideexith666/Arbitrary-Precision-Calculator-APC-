/* 
 Name : G Sai Deexith Kumar Reddy
 Date : 03.08.2025
 Description : APC (Arbitary precision calculator)
*/
#include "Dll.h"

// Performs head1 - head2 (assumes head1 >= head2 based on compare_numbers)
int sub_number(Dlist **head1, Dlist **tail1,
               Dlist **head2, Dlist **tail2,
               Dlist **head3, Dlist **tail3,
               char *op1, char *op2)
{
    compare_numbers(head1, tail1, head2, tail2, op1, op2);

    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;
    int borrow = 0;

    while (temp1 != NULL)
    {
        int num1 = temp1->data;
        int num2 = (temp2 != NULL) ? temp2->data : 0;

        if (borrow)
        {
            num1--;
            borrow = 0;
        }

        if (num1 < num2)
        {
            num1 += 10;
            borrow = 1;
        }

        int result = num1 - num2;
        dl_insert_first(head3, tail3, result);

        temp1 = temp1->prev;
        if (temp2 != NULL)
            temp2 = temp2->prev;
    }

    // Remove leading zeros
    while (*head3 != NULL && (*head3)->data == 0)
    {
        dl_delete_first(head3, tail3);
    }

    // If result is zero
    if (*head3 == NULL)
    {
        dl_insert_first(head3, tail3, 0);
    }

    return SUCCESS;
}

// Compares two number lists by digit count and content
// Returns 0 if op1 >= op2, 1 if op1 < op2
int compare_numbers(Dlist **head1, Dlist **tail1,
                    Dlist **head2, Dlist **tail2,
                    char *op1, char *op2)
{
    int len1 = 0, len2 = 0;
    Dlist *temp1 = *head1;
    Dlist *temp2 = *head2;

    while (temp1) { len1++; temp1 = temp1->next; }
    while (temp2) { len2++; temp2 = temp2->next; }

    if (len1 < len2 || (len1 == len2 && compare_lists(*head1, *head2) < 0))
    {
        swap_lists(head1, tail1, head2, tail2);
        return 1;
    }
    return 0;
}

// Compares two linked lists digit by digit
// Returns 1 if a > b, -1 if a < b, 0 if equal
int compare_lists(Dlist *a, Dlist *b)
{
    while (a && b)
    {
        if (a->data > b->data) return 1;
        if (a->data < b->data) return -1;
        a = a->next;
        b = b->next;
    }
    return 0;
}

// Swaps two linked lists (used when operand2 > operand1)
void swap_lists(Dlist **head1, Dlist **tail1,
                Dlist **head2, Dlist **tail2)
{
    Dlist *temp;

    temp = *head1;
    *head1 = *head2;
    *head2 = temp;

    temp = *tail1;
    *tail1 = *tail2;
    *tail2 = temp;
}
