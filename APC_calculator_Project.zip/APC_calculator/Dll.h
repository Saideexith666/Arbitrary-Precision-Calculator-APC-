/* 
 Name : G Sai Deexith Kumar Reddy
 Date : 03.08.2025
 Description : APC (Arbitary precision calculator)
*/
#ifndef DLL_H
#define DLL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCCESS 0
#define FAILURE -1

typedef int data_t;

// Doubly Linked List Node Structure
typedef struct node
{
    struct node *prev;
    data_t data;
    struct node *next;
} Dlist;

// Linked List Operations
int dl_insert_first(Dlist **head, Dlist **tail, int data);
int dl_insert_last(Dlist **head, Dlist **tail, int data);
int dl_delete_first(Dlist **head, Dlist **tail);
int dl_delete_list(Dlist **head, Dlist **tail);
void print_list(Dlist *head);
int stored_num(Dlist **head, Dlist **tail, char *data);
int is_zero(Dlist *head);

// Addition
int updata_result_add(Dlist **head, Dlist **tail, int result, int *carry);
int add_number(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **head3, Dlist **tail3);

// Subtraction
int sub_number(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **head3, Dlist **tail3,char *op1, char *op2);

int compare_numbers(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,char *op1, char *op2);

int compare_lists(Dlist *a, Dlist *b);

void swap_lists(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2);

// Multiplication
int mul_number(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **head3, Dlist **tail3);

// Division
int div_number(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **head3, Dlist **tail3,char ch);

int compare_num(Dlist *head2, Dlist *tail2,Dlist *list_h, Dlist *list_t);

int do_divided(Dlist **list_h, Dlist **list_t,Dlist **head2, Dlist **tail2,Dlist **head3, Dlist **tail3,Dlist **h_div, Dlist **t_div,Dlist *temp);

int sub_number_div(Dlist **list_h, Dlist **list_t,Dlist **head2, Dlist **tail2,Dlist **head3, Dlist **tail3);

#endif
