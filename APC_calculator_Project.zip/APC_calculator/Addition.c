/* 
 Name : G Sai Deexith Kumar Reddy
 Date : 03.08.2025
 Description : APC (Arbitary precision calculator)
*/
#include "Dll.h"

int add_number(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **head3, Dlist **tail3)
{
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;
    int carry = 0;

    while (temp1 != NULL || temp2 != NULL)
    {
        int num1 = (temp1 != NULL) ? temp1->data : 0;
        int num2 = (temp2 != NULL) ? temp2->data : 0;

        int result = num1 + num2 + carry;
        updata_result_add(head3, tail3, result, &carry);

        if (temp1 != NULL) temp1 = temp1->prev;
        if (temp2 != NULL) temp2 = temp2->prev;
    }

    // Add remaining carry if present
    if (carry != 0)
    {
        dl_insert_first(head3, tail3, carry);
    }

    return SUCCESS;
}

int updata_result_add(Dlist **head, Dlist **tail, int result, int *carry)
{
    if (result > 9)
    {
        int digit = result % 10;
        dl_insert_first(head, tail, digit);
        *carry = result / 10;
    }
    else
    {
        dl_insert_first(head, tail, result);
        *carry = 0;
    }

    return SUCCESS;
}
