/* 
 Name : G Sai Deexith Kumar Reddy
 Date : 03.08.2025
 Description : APC (Arbitary precision calculator)
*/
#include "Dll.h"

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Invalid arguments!!!! -> ./a.out <num1> <(+,-,x,/)> <num2>\n");
        return 1;
    }

    char *op1_str = argv[1];
    char *op2_str = argv[3];
    char operator = argv[2][0];

    if (operator != '+' && operator != '-' && operator != 'x' && operator != '/')
    {
        printf("Invalid operation!!!! -> ./a.out <num1> <(+,-,x,/)> <num2>\n");
        return 1;
    }

    int sign1 = 1, sign2 = 1;
    if (op1_str[0] == '-') { sign1 = -1; op1_str++; }
    if (op2_str[0] == '-') { sign2 = -1; op2_str++; }

    Dlist *head1 = NULL, *tail1 = NULL;
    Dlist *head2 = NULL, *tail2 = NULL;
    Dlist *head3 = NULL, *tail3 = NULL;

    stored_num(&head1, &tail1, op1_str);
    stored_num(&head2, &tail2, op2_str);

    int result_sign = 1;

    switch (operator)
    {
        case '+':
            if (sign1 == sign2)
            {
                result_sign = sign1;
                add_number(&head1, &tail1, &head2, &tail2, &head3, &tail3);
            }
            else
            {
                int cmp = compare_numbers(&head1, &tail1, &head2, &tail2, op1_str, op2_str);
                result_sign = (cmp == 0) ? sign1 : (cmp == 1 ? sign2 : sign1);
                sub_number(&head1, &tail1, &head2, &tail2, &head3, &tail3, op1_str, op2_str);
            }
            break;

        case '-':
            if (sign1 != sign2)
            {
                result_sign = sign1;
                add_number(&head1, &tail1, &head2, &tail2, &head3, &tail3);
            }
            else
            {
                int cmp = compare_numbers(&head1, &tail1, &head2, &tail2, op1_str, op2_str);
                result_sign = (cmp == 0) ? sign1 : (cmp == 1 ? -sign1 : sign1);
                sub_number(&head1, &tail1, &head2, &tail2, &head3, &tail3, op1_str, op2_str);
            }
            break;

        case 'x':
            result_sign = sign1 * sign2;
            mul_number(&head1, &tail1, &head2, &tail2, &head3, &tail3);
            break;

        case '/':
            if (head2 == NULL || is_zero(head2))
            {
                printf("Error: Division by zero.\n");
                return 1;
            }
            result_sign = sign1 * sign2;
            div_number(&head1, &tail1, &head2, &tail2, &head3, &tail3, operator);
            break;
    }

    if (head3 == NULL)
    {
        printf("0\n");
        return 0;
    }

    if (result_sign == -1)
        printf("-");

    print_list(head3);
    printf("\n");

    return 0;
}
