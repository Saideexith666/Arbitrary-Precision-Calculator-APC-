/* 
 Name : G Sai Deexith Kumar Reddy
 Date : 03.08.2025
 Description : APC (Arbitary precision calculator)
*/
#include "Dll.h"

// Convert string to doubly linked list (digit by digit)
int stored_num(Dlist **head, Dlist **tail, char *data)
{
    int i = 0;
    while (data[i] != '\0')
    {
        if (data[i] >= '0' && data[i] <= '9')
        {
            dl_insert_last(head, tail, data[i] - '0');
        }
        i++;
    }
    return SUCCESS;
}

// Insert node at the end
int dl_insert_last(Dlist **head, Dlist **tail, int data)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (!new) return FAILURE;

    new->data = data;
    new->prev = new->next = NULL;

    if (*head == NULL)
    {
        *head = *tail = new;
    }
    else
    {
        new->prev = *tail;
        (*tail)->next = new;
        *tail = new;
    }
    return SUCCESS;
}

// Insert node at the beginning
int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (!new) return FAILURE;

    new->data = data;
    new->next = new->prev = NULL;

    if (*head == NULL)
    {
        *head = *tail = new;
    }
    else
    {
        new->next = *head;
        (*head)->prev = new;
        *head = new;
    }
    return SUCCESS;
}

// Print the number stored in the linked list
void print_list(Dlist *head)
{
    while (head)
    {
        printf("%d", head->data);
        head = head->next;
    }
}

// Delete all nodes in the list
int dl_delete_list(Dlist **head, Dlist **tail)
{
    Dlist *temp = *head;
    while (temp)
    {
        Dlist *next = temp->next;
        free(temp);
        temp = next;
    }
    *head = *tail = NULL;
    return SUCCESS;
}

// Delete the first node of the list
int dl_delete_first(Dlist **head, Dlist **tail)
{
    if (*head == NULL)
        return FAILURE;

    Dlist *temp = *head;
    if (*head == *tail)
    {
        *head = *tail = NULL;
    }
    else
    {
        *head = (*head)->next;
        (*head)->prev = NULL;
    }
    free(temp);
    return SUCCESS;
}

// Check if the number is zero (used for division safety)
int is_zero(Dlist *head)
{
    while (head)
    {
        if (head->data != 0)
            return 0;
        head = head->next;
    }
    return 1;
}
