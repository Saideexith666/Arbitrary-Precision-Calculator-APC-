/* 
 Name : G Sai Deexith Kumar Reddy
 Date : 03.08.2025
 Description : APC (Arbitary precision calculator)
*/
#include "Dll.h"

int mul_number(Dlist **head1, Dlist **tail1,
               Dlist **head2, Dlist **tail2,
               Dlist **head3, Dlist **tail3)
{
    Dlist *res1_h = NULL, *res1_t = NULL;
    Dlist *res2_h = NULL, *res2_t = NULL;
    Dlist *res3_h = NULL, *res3_t = NULL;

    int value = 0, count = 0;

    dl_insert_first(&res2_h, &res2_t, value);

    Dlist *temp2 = *tail2;

    while (temp2 != NULL)
    {
        Dlist *temp1 = *tail1;

        // Insert leading zeros for position
        for (int i = 0; i < count; i++)
        {
            dl_insert_first(&res1_h, &res1_t, 0);
        }

        int carry = 0;
        while (temp1 != NULL)
        {
            int num1 = temp1->data;
            int num2 = temp2->data;

            int product = num1 * num2 + carry;
            int digit = product % 10;
            carry = product / 10;

            dl_insert_first(&res1_h, &res1_t, digit);
            temp1 = temp1->prev;
        }

        if (carry)
        {
            dl_insert_first(&res1_h, &res1_t, carry);
        }

        add_number(&res1_h, &res1_t, &res2_h, &res2_t, &res3_h, &res3_t);

        // Prepare for next digit multiplication
        res2_h = res3_h;
        res2_t = res3_t;

        res3_h = NULL;
        res3_t = NULL;

        dl_delete_list(&res1_h, &res1_t);
        temp2 = temp2->prev;
        count++;
    }

    // Final result
    *head3 = res2_h;
    *tail3 = res2_t;

    // Remove leading zeros
    while (*head3 != NULL && (*head3)->data == 0)
    {
        dl_delete_first(head3, tail3);
    }

    // If result is zero
    if (*head3 == NULL)
    {
        dl_insert_first(head3, tail3, 0);
    }

    return SUCCESS;
}

